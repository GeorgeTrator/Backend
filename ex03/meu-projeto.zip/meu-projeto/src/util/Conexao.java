package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
private static final String URL = "jdbc:mysql://localhost:3306/sistema_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&useUnicode=true&characterEncoding=UTF-8";    private static final String USER = "root";     // Substitua pelo seu usuario do MySQL
    private static final String PASS = "univille"; // Substitua pela sua senha do MySQL

    public static Connection getConexao() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}