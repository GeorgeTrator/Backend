CREATE DATABASE IF NOT EXISTS sistema_db;
USE sistema_db;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL
);

INSERT INTO usuarios (nome, email) VALUES ('Carlos Silva', 'carlos@email.com');
INSERT INTO usuarios (nome, email) VALUES ('Isaac Newton', 'newtonDaMassa@gravidade.com')