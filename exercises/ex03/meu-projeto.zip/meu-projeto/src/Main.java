import model.Usuario;
import model.UsuarioDAO;

//Jimport java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        UsuarioDAO dao = new UsuarioDAO();

        Scanner e = new Scanner(System.in); 

        System.out.println("--- Testando Alteracao (INSERT) ---");
        System.out.print("Informe um nome: ");
        String nome = e.nextLine(); 

        System.out.print("Informe um email: ");
        String email = e.nextLine(); 

        Usuario novoUsuario = new Usuario(nome, email);
        dao.inserir(novoUsuario);

        // 2. Realizando a consulta (SELECT)
        System.out.println("\n--- Testando Busca (SELECT) ---");
        List<Usuario> resultados = dao.buscarTodos();
        for (Usuario u : resultados) {
            System.out.println(u);
        }

        e.close();
    }
}