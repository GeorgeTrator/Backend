-- =========================================================
--  CineSexta13 — Catálogo de Filmes (Simulado Back-end)
--  5 tabelas: Genero, Diretor, Filme, Usuario, Avaliacao
-- =========================================================

DROP DATABASE IF EXISTS filmes_db;
CREATE DATABASE filmes_db;
USE filmes_db;

-- 1) Gênero do filme (Terror, Comédia...)
CREATE TABLE Genero (
    id_genero   INT AUTO_INCREMENT PRIMARY KEY,
    nome_genero VARCHAR(50) NOT NULL UNIQUE
);

-- 2) Diretor do filme
CREATE TABLE Diretor (
    id_diretor    INT AUTO_INCREMENT PRIMARY KEY,
    nome_diretor  VARCHAR(100) NOT NULL,
    nacionalidade VARCHAR(50)
);

-- 3) Filme: todo filme tem UM gênero e UM diretor
CREATE TABLE Filme (
    id_filme       INT AUTO_INCREMENT PRIMARY KEY,
    titulo         VARCHAR(150) NOT NULL,
    ano_lancamento INT NOT NULL,
    duracao_min    INT,
    classificacao  INT,          -- idade indicativa: 0 (livre), 10, 12, 14, 16, 18
    sinopse        TEXT,
    id_genero      INT NOT NULL,
    id_diretor     INT NOT NULL,
    FOREIGN KEY (id_genero)  REFERENCES Genero(id_genero),
    FOREIGN KEY (id_diretor) REFERENCES Diretor(id_diretor)
);

-- 4) Usuário do site
CREATE TABLE Usuario (
    id_usuario   INT AUTO_INCREMENT PRIMARY KEY,
    nome_usuario VARCHAR(100) NOT NULL,
    email        VARCHAR(150) NOT NULL UNIQUE
);

-- 5) Avaliação: um usuário dá uma nota (0 a 10) para um filme
CREATE TABLE Avaliacao (
    id_avaliacao INT AUTO_INCREMENT PRIMARY KEY,
    nota         INT NOT NULL,
    comentario   TEXT,           -- pode ser NULL (avaliação só com nota)
    id_filme     INT NOT NULL,
    id_usuario   INT NOT NULL,
    FOREIGN KEY (id_filme)   REFERENCES Filme(id_filme),
    FOREIGN KEY (id_usuario) REFERENCES Usuario(id_usuario)
);

-- ---------------------------------------------------------
--  Dados
-- ---------------------------------------------------------

INSERT INTO Genero (nome_genero) VALUES
('Terror'),             -- 1
('Suspense'),           -- 2
('Ficção Científica'),  -- 3
('Comédia'),            -- 4
('Animação');           -- 5

INSERT INTO Diretor (nome_diretor, nacionalidade) VALUES
('Sean S. Cunningham', 'Estados Unidos'),  -- 1
('John Carpenter',     'Estados Unidos'),  -- 2
('Wes Craven',         'Estados Unidos'),  -- 3
('Jordan Peele',       'Estados Unidos'),  -- 4
('Steven Spielberg',   'Estados Unidos'),  -- 5
('Hayao Miyazaki',     'Japão'),           -- 6
('Henry Selick',       'Estados Unidos'),  -- 7
('José Mojica Marins', 'Brasil'),          -- 8
('Ivan Reitman',       'Canadá');          -- 9

INSERT INTO Filme (titulo, ano_lancamento, duracao_min, classificacao, sinopse, id_genero, id_diretor) VALUES
('Sexta-Feira 13', 1980, 95, 18, 'Monitores reabrem um acampamento à beira de um lago, mas alguém começa a eliminá-los um a um.', 1, 1),
('Halloween: A Noite do Terror', 1978, 91, 16, 'Um assassino foge do sanatório e volta à sua cidade natal na noite de Halloween.', 1, 2),
('O Enigma de Outro Mundo', 1982, 109, 18, 'Pesquisadores na Antártida enfrentam uma criatura capaz de imitar qualquer ser vivo.', 1, 2),
('A Hora do Pesadelo', 1984, 91, 18, 'Adolescentes são perseguidos nos sonhos por uma figura assustadora.', 1, 3),
('Pânico', 1996, 111, 16, 'Um assassino mascarado aterroriza estudantes que conhecem todas as regras dos filmes de terror.', 1, 3),
('Corra!', 2017, 104, 14, 'Um jovem visita a família da namorada e descobre que há algo muito estranho naquela casa.', 2, 4),
('Nós', 2019, 116, 16, 'Uma família em férias é confrontada por sósias de si mesmos.', 1, 4),
('Tubarão', 1975, 124, 14, 'Um tubarão gigante ataca banhistas em uma cidade litorânea.', 2, 5),
('E.T. - O Extraterrestre', 1982, 115, 0, 'Um garoto faz amizade com um extraterrestre perdido na Terra.', 3, 5),
('A Viagem de Chihiro', 2001, 125, 0, 'Uma menina fica presa em um mundo de espíritos e precisa salvar os pais.', 5, 6),
('O Estranho Mundo de Jack', 1993, 76, 0, 'O rei da Cidade do Halloween descobre o Natal e decide comandá-lo.', 5, 7),
('Coraline e o Mundo Secreto', 2009, 100, 10, 'Uma garota encontra uma porta secreta para uma versão "perfeita" da sua casa.', 5, 7),
('À Meia-Noite Levarei Sua Alma', 1964, 84, 16, 'Um coveiro cruel aterroriza uma pequena cidade em busca da mulher ideal.', 1, 8),
('Os Caça-Fantasmas', 1984, 105, 10, 'Três cientistas abrem uma empresa para capturar fantasmas em Nova York.', 4, 9);

INSERT INTO Usuario (nome_usuario, email) VALUES
('Ana Lima',    'ana@email.com'),    -- 1
('Bruno Costa', 'bruno@email.com'),  -- 2
('Carla Souza', 'carla@email.com'),  -- 3
('Diego Alves', 'diego@email.com'),  -- 4
('Elisa Rocha', 'elisa@email.com');  -- 5

INSERT INTO Avaliacao (nota, comentario, id_filme, id_usuario) VALUES
(9,  'Clássico obrigatório para uma sexta-feira 13!', 1, 1),
(7,  'Assusta, mas envelheceu um pouco.',            1, 2),
(10, 'A trilha sonora é inesquecível.',              2, 3),
(8,  NULL,                                           3, 1),
(9,  'Não consegui dormir depois.',                  4, 4),
(8,  'Mistura terror e humor muito bem.',            5, 2),
(10, 'Roteiro genial.',                              6, 5),
(6,  NULL,                                           7, 3),
(9,  'Nunca mais entro no mar.',                     8, 4),
(10, 'Chorei no final.',                             9, 1),
(10, 'Animação perfeita.',                           10, 5),
(8,  'Bom para assistir em família.',                11, 2),
(7,  'Divertido e nostálgico.',                      14, 3);

-- Teste rápido
SELECT * FROM Filme;
