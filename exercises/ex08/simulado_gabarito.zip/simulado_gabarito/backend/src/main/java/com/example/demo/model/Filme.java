package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Filme")
public class Filme {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_filme")
    private Integer id;

    @Column(name = "titulo")
    private String titulo;

    @Column(name = "ano_lancamento")
    private Integer anoLancamento;

    @Column(name = "duracao_min")
    private Integer duracaoMin;

    // idade indicativa: 0 (livre), 10, 12, 14, 16, 18
    @Column(name = "classificacao")
    private Integer classificacao;

    @Column(name = "sinopse")
    private String sinopse;

    // Muitos filmes para um gênero
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_genero", nullable = false)
    private Genero genero;

    // Muitos filmes para um diretor
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_diretor", nullable = false)
    private Diretor diretor;

    public Integer getId() { return id; }
    public String getTitulo() { return titulo; }
    public Integer getAnoLancamento() { return anoLancamento; }
    public Integer getDuracaoMin() { return duracaoMin; }
    public Integer getClassificacao() { return classificacao; }
    public String getSinopse() { return sinopse; }
    public Genero getGenero() { return genero; }
    public Diretor getDiretor() { return diretor; }
}
