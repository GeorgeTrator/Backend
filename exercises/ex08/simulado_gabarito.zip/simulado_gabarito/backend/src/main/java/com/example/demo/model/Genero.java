package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Genero")
public class Genero {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_genero")
    private Integer id;

    @Column(name = "nome_genero")
    private String nomeGenero;

    public Integer getId() { return id; }
    public String getNomeGenero() { return nomeGenero; }
}
