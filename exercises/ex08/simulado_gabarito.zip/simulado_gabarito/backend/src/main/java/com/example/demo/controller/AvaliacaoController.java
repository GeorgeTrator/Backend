package com.example.demo.controller;

import com.example.demo.model.Avaliacao;
import com.example.demo.repository.AvaliacaoRepository;
import com.example.demo.repository.FilmeRepository;
import com.example.demo.repository.UsuarioRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class AvaliacaoController {

    private final AvaliacaoRepository avaliacaoRepository;
    private final FilmeRepository filmeRepository;
    private final UsuarioRepository usuarioRepository;

    public AvaliacaoController(AvaliacaoRepository avaliacaoRepository,
                               FilmeRepository filmeRepository,
                               UsuarioRepository usuarioRepository) {
        this.avaliacaoRepository = avaliacaoRepository;
        this.filmeRepository = filmeRepository;
        this.usuarioRepository = usuarioRepository;
    }

    // GET /avaliacoes/filme?id=1  ->  avaliações de um filme
    @GetMapping("/avaliacoes/filme")
    public ResponseEntity<List<Avaliacao>> buscarPorFilme(@RequestParam Integer id) {
        return ResponseEntity.ok(avaliacaoRepository.buscarPorFilme(id));
    }

    // Exercício 2: DELETE /avaliacoes/3  ->  apaga a avaliação 3
    @DeleteMapping("/avaliacoes/{id}")
    public ResponseEntity<String> apagar(@PathVariable Integer id) {
        if (!avaliacaoRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        avaliacaoRepository.deleteById(id);
        return ResponseEntity.ok("Avaliação " + id + " apagada.");
    }

    // Exercício 4: PUT /avaliacoes/3  ->  altera nota e comentário da avaliação 3
    @PutMapping("/avaliacoes/{id}")
    public ResponseEntity<String> atualizar(@PathVariable Integer id, @RequestBody Avaliacao dados) {
        Avaliacao avaliacao = avaliacaoRepository.findById(id).orElse(null);

        if (avaliacao == null) {
            return ResponseEntity.notFound().build();
        }
        if (dados.getNota() == null || dados.getNota() < 0 || dados.getNota() > 10) {
            return ResponseEntity.badRequest().body("A nota deve ser de 0 a 10.");
        }

        avaliacao.setNota(dados.getNota());
        avaliacao.setComentario(dados.getComentario());
        avaliacaoRepository.save(avaliacao);   // id já existe -> UPDATE

        return ResponseEntity.ok("Avaliação " + id + " atualizada.");
    }

    // Exercício 5: POST /avaliacoes  ->  cadastra uma avaliação nova
    // JSON esperado: { "nota": 9, "comentario": "...", "filme": { "id": 1 }, "usuario": { "id": 2 } }
    @PostMapping("/avaliacoes")
    public ResponseEntity<String> cadastrar(@RequestBody Avaliacao avaliacao) {
        if (avaliacao.getFilme() == null || !filmeRepository.existsById(avaliacao.getFilme().getId())) {
            return ResponseEntity.badRequest().body("Filme não encontrado.");
        }
        if (avaliacao.getUsuario() == null || !usuarioRepository.existsById(avaliacao.getUsuario().getId())) {
            return ResponseEntity.badRequest().body("Usuário não encontrado.");
        }
        if (avaliacao.getNota() == null || avaliacao.getNota() < 0 || avaliacao.getNota() > 10) {
            return ResponseEntity.badRequest().body("A nota deve ser de 0 a 10.");
        }

        Avaliacao salva = avaliacaoRepository.save(avaliacao);   // sem id -> INSERT
        return ResponseEntity.ok("Avaliação cadastrada com id " + salva.getId());
    }
}
