package com.example.demo.model;

// Projeção: só as colunas que queremos exibir no resumo.
// Cada getter casa com um apelido (AS ...) da consulta nativa.
public interface FilmeResumo {

    String getTitulo();
    Integer getAno();
    String getGenero();
    String getDiretor();
    Double getMedia();   // média das notas (vem NULL se o filme não tiver avaliações)

}
