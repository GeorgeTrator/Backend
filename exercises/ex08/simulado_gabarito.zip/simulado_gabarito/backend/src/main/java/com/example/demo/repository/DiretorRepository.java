package com.example.demo.repository;

import com.example.demo.model.Diretor;
import org.springframework.data.jpa.repository.JpaRepository;

// Herdando JpaRepository ganhamos: findAll(), findById(id), save(obj),
// deleteById(id), existsById(id), count()...
public interface DiretorRepository extends JpaRepository<Diretor, Integer> {
}
