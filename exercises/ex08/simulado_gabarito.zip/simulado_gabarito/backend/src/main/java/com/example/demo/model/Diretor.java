package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Diretor")
public class Diretor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_diretor")
    private Integer id;

    @Column(name = "nome_diretor")
    private String nomeDiretor;

    @Column(name = "nacionalidade")
    private String nacionalidade;

    public Integer getId() { return id; }
    public String getNomeDiretor() { return nomeDiretor; }
    public String getNacionalidade() { return nacionalidade; }
}
