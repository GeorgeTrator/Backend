package com.example.demo.controller;

import com.example.demo.model.Filme;
import com.example.demo.model.FilmeResumo;
import com.example.demo.repository.FilmeRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class FilmeController {

    private final FilmeRepository filmeRepository;

    public FilmeController(FilmeRepository filmeRepository) {
        this.filmeRepository = filmeRepository;
    }

    // GET /filmes  ->  todos os filmes
    @GetMapping("/filmes")
    public ResponseEntity<List<Filme>> listarTodos() {
        return ResponseEntity.ok(filmeRepository.listarTodos());
    }

    // GET /filmes/genero?nome=Terror  ->  filmes de um gênero
    @GetMapping("/filmes/genero")
    public ResponseEntity<List<Filme>> buscarPorGenero(@RequestParam String nome) {
        List<Filme> filmes = filmeRepository.buscarPorGenero(nome);
        return ResponseEntity.ok(filmes);
    }

    // GET /filmes/resumo?id=1  ->  "titulo (ano) | genero | diretor | nota média"
    @GetMapping("/filmes/resumo")
    public ResponseEntity<String> buscarResumo(@RequestParam Integer id) {
        FilmeResumo resumo = filmeRepository.buscarResumoPorId(id);

        if (resumo == null) {
            return ResponseEntity.notFound().build();
        }

        String media = resumo.getMedia() == null ? "sem avaliações" : "nota média " + resumo.getMedia();

        return ResponseEntity.ok(resumo.getTitulo() + " (" + resumo.getAno() + ") | "
                + resumo.getGenero() + " | " + resumo.getDiretor() + " | " + media);
    }

    // Exercício 1: GET /filmes/diretor?nome=John Carpenter
    @GetMapping("/filmes/diretor")
    public ResponseEntity<List<Filme>> buscarPorDiretor(@RequestParam String nome) {
        List<Filme> filmes = filmeRepository.buscarPorDiretor(nome);
        return ResponseEntity.ok(filmes);
    }
}
