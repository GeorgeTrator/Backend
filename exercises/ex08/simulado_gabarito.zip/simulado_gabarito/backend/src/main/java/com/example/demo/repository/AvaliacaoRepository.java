package com.example.demo.repository;

import com.example.demo.model.Avaliacao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AvaliacaoRepository extends JpaRepository<Avaliacao, Integer> {

    // Avaliações de um filme, já trazendo o usuário e o filme (com gênero e diretor)
    @Query("SELECT a FROM Avaliacao a " +
           "JOIN FETCH a.usuario " +
           "JOIN FETCH a.filme f " +
           "JOIN FETCH f.genero " +
           "JOIN FETCH f.diretor " +
           "WHERE f.id = :idFilme")
    List<Avaliacao> buscarPorFilme(
        @Param("idFilme")
        Integer idFilme
    );
}
