package com.example.demo.controller;

import com.example.demo.model.Diretor;
import com.example.demo.repository.DiretorRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class DiretorController {

    private final DiretorRepository diretorRepository;

    public DiretorController(DiretorRepository diretorRepository) {
        this.diretorRepository = diretorRepository;
    }

    // Exercício 3: GET /diretores  ->  lista todos os diretores
    @GetMapping("/diretores")
    public ResponseEntity<List<Diretor>> listarTodos() {
        return ResponseEntity.ok(diretorRepository.findAll());
    }

    // Exercício 3: POST /diretores  ->  cadastra um diretor
    // O JSON do corpo vira um objeto Diretor graças ao @RequestBody
    @PostMapping("/diretores")
    public ResponseEntity<String> cadastrar(@RequestBody Diretor diretor) {
        Diretor salvo = diretorRepository.save(diretor);
        return ResponseEntity.ok("Diretor cadastrado com id " + salvo.getId());
    }
}
