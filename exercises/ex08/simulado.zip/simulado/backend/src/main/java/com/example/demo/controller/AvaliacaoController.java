package com.example.demo.controller;

import com.example.demo.model.Avaliacao;
import com.example.demo.repository.AvaliacaoRepository;
import com.example.demo.repository.FilmeRepository;
import com.example.demo.repository.UsuarioRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class AvaliacaoController {

    // Os três repositórios já estão injetados: você vai precisar deles nos exercícios
    private final AvaliacaoRepository avaliacaoRepository;
    private final FilmeRepository filmeRepository;
    private final UsuarioRepository usuarioRepository;

    public AvaliacaoController(AvaliacaoRepository avaliacaoRepository,
                               FilmeRepository filmeRepository,
                               UsuarioRepository usuarioRepository) {
        this.avaliacaoRepository = avaliacaoRepository;
        this.filmeRepository = filmeRepository;
        this.usuarioRepository = usuarioRepository;
    }

    // GET /avaliacoes/filme?id=1  ->  avaliações de um filme
    @GetMapping("/avaliacoes/filme")
    public ResponseEntity<List<Avaliacao>> buscarPorFilme(@RequestParam Integer id) {
        return ResponseEntity.ok(avaliacaoRepository.buscarPorFilme(id));
    }

    // Exercício 2: crie aqui o DELETE /avaliacoes/{id}

    // Exercício 4: crie aqui o PUT /avaliacoes/{id}

    // Exercício 5: crie aqui o POST /avaliacoes

}
