package com.example.demo.controller;

import com.example.demo.repository.DiretorRepository;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class DiretorController {

    private final DiretorRepository diretorRepository;

    public DiretorController(DiretorRepository diretorRepository) {
        this.diretorRepository = diretorRepository;
    }

    // Exercício 3: crie aqui o GET /diretores (lista todos)

    // Exercício 3: crie aqui o POST /diretores (cadastra um diretor)

}
