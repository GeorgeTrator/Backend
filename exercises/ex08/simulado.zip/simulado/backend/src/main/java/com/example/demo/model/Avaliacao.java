package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Avaliacao")
public class Avaliacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_avaliacao")
    private Integer id;

    // nota de 0 a 10
    @Column(name = "nota")
    private Integer nota;

    // pode ser NULL
    @Column(name = "comentario")
    private String comentario;

    // Muitas avaliações para um filme
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_filme", nullable = false)
    private Filme filme;

    // Muitas avaliações para um usuário
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    public Integer getId() { return id; }
    public Integer getNota() { return nota; }
    public String getComentario() { return comentario; }
    public Filme getFilme() { return filme; }
    public Usuario getUsuario() { return usuario; }
}
