package com.example.agencia.repository;

import com.example.agencia.model.Espiao;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

/*
Aqui nós dizemos como realizar consultas no banco para uma determianda tabela
Ao herdar JpaRepository ganhamos uma série de métodos como 
findAll(): todos os registros
findById(id): um registro pelo id
save(obj): insere ou atualiza
deleteById(id): apaga
count(), existsById(id), e outros
*/

public interface EspiaoRepository extends JpaRepository<Espiao, Integer> {

    // Equivale a: SELECT * FROM Espiao WHERE id_agencia = ?
    // em que '?' é o parâmetro idAgencia que passamos para o método
    List<Espiao> findByIdAgencia(Integer idAgencia);
}