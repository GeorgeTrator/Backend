package com.example.agencia.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Espiao")
public class Espiao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_espiao")
    private Integer id;

    @Column(name = "nome_real")
    private String nomeReal;

    @Column(name = "nome_espiao")
    private String nomeEspiao;

    @Column(name = "descricao")
    private String descricao;

    // Aqui id_agencia é só o NÚMERO da chave estrangeira, não a agência em si.
    // Se usássemos @ManyToOne + @JoinColumn, o campo seria o objeto Agencia inteiro
    // e o Hibernate faria o JOIN sozinho quando precisássemos do nome da agência.
    // Não se preocupe com os nomes agora (Hibernate, JPA, etc), só saiba que o campo é o número da agência, não a agência em si.
    // Futuramente vamos refatorar este código.
    @Column(name = "id_agencia")
    private Integer idAgencia;

    public Integer getId() { return id; }
    public String getNomeReal() { return nomeReal; }
    public String getNomeEspiao() { return nomeEspiao; }
    public String getDescricao() { return descricao; }
    public Integer getIdAgencia() { return idAgencia; }
}