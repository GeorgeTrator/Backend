package com.example.agencia.controller;

import com.example.agencia.model.Agencia;
import com.example.agencia.model.Espiao;
import com.example.agencia.repository.AgenciaRepository;
import com.example.agencia.repository.EspiaoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController //define que esta classe recebe requisições HTTP e retorna JSON
@CrossOrigin // libera o front-end para acessar a API (evita erro CORS)
// CORS = Cross-Origin Resource Sharing, é uma política de segurança que impede que um site faça requisições para outro site em um domínio diferente.
// domínio = protocolo + host + porta, por exemplo: http://localhost:3000
public class EspiaoController {

    private final AgenciaRepository agenciaRepository;
    private final EspiaoRepository espiaoRepository;

    public EspiaoController(AgenciaRepository agenciaRepository,
                            EspiaoRepository espiaoRepository) {
        this.agenciaRepository = agenciaRepository;
        this.espiaoRepository = espiaoRepository;
    }

    // Define que este método responde a requisições GET no caminho /espioes
    // @RequestParam indica que o parâmetro 'agencia' vem da query string da URL, por exemplo: /espioes?agencia=MI6
    @GetMapping("/espioes")
    public ResponseEntity<List<Espiao>> buscarPorAgencia(@RequestParam String agencia) {

        // Equivale a: SELECT * FROM Agencia WHERE nome_agencia = ?
        // (o ? recebe o nome em maiúsculas, ex.: 'CIA')
        Agencia ag = agenciaRepository.findByNomeAgencia(agencia.toUpperCase());

        if (ag == null) {
            return ResponseEntity.notFound().build();
        }

        // Equivale a: SELECT * FROM Espiao WHERE id_agencia = ?
        // (o ? recebe o id da agência encontrada acima)
        List<Espiao> espioes = espiaoRepository.findByIdAgencia(ag.getId());
        return ResponseEntity.ok(espioes); // Retorna para o Spring Web, que irá converter o objeto java em um JSON

        /*
            Observe que as duas operações equivalem, logicamente, a 
            SELECT e FROM Espiao e JOIN e.agencia a WHERE a.nomeAgencia = nome
            Mas a aplicação real não é a mesma coisa. No nosso caso, fazemos duas consultas ao banco de dados.
            Com o JOIN é apenas uma consulta. 
         */
    }
}
