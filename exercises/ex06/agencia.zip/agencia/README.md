
```
agencia
├─ back-end
│  ├─ .mvn
│  │  └─ wrapper
│  │     └─ maven-wrapper.properties
│  ├─ HELP.md
│  ├─ mvnw
│  ├─ mvnw.cmd
│  ├─ pom.xml
│  ├─ src
│  │  ├─ main
│  │  │  ├─ java
│  │  │  │  └─ com
│  │  │  │     └─ example
│  │  │  │        └─ agencia
│  │  │  │           ├─ AgenciaApplication.java
│  │  │  │           ├─ controller
│  │  │  │           │  └─ EspiaoController.java
│  │  │  │           ├─ model
│  │  │  │           │  ├─ Agencia.java
│  │  │  │           │  └─ Espiao.java
│  │  │  │           └─ repository
│  │  │  │              ├─ AgenciaRepository.java
│  │  │  │              └─ EspiaoRepository.java
│  │  │  └─ resources
│  │  │     ├─ application.properties
│  │  │     ├─ static
│  │  │     └─ templates
│  │  └─ test
│  │     └─ java
│  │        └─ com
│  │           └─ example
│  │              └─ agencia
│  │                 └─ AgenciaApplicationTests.java
│  └─ target
│     ├─ classes
│     │  ├─ application.properties
│     │  └─ com
│     │     └─ example
│     │        └─ agencia
│     │           ├─ AgenciaApplication.class
│     │           ├─ controller
│     │           │  └─ EspiaoController.class
│     │           ├─ model
│     │           │  ├─ Agencia.class
│     │           │  └─ Espiao.class
│     │           └─ repository
│     │              ├─ AgenciaRepository.class
│     │              └─ EspiaoRepository.class
│     └─ test-classes
│        └─ com
│           └─ example
│              └─ agencia
│                 └─ AgenciaApplicationTests.class
├─ database
│  └─ schema.sql
├─ front-end
│  └─ index.html
└─ README.md

```