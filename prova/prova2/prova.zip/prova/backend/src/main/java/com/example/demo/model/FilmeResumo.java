package com.example.demo.model;

public interface FilmeResumo {

    String getTitulo();
    Integer getAno();
    String getGenero();
    String getDiretor();
    Double getMedia();

}
