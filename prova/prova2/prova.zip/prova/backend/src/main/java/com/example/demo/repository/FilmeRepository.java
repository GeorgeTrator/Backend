package com.example.demo.repository;

import com.example.demo.model.Filme;
import com.example.demo.model.FilmeResumo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FilmeRepository extends JpaRepository<Filme, Integer> {

    @Query("SELECT f FROM Filme f JOIN FETCH f.genero JOIN FETCH f.diretor ORDER BY f.titulo")
    List<Filme> listarTodos();

    @Query("SELECT f FROM Filme f JOIN FETCH f.genero g JOIN FETCH f.diretor WHERE g.nomeGenero = :nomeGenero")
    List<Filme> buscarPorGenero(
        @Param("nomeGenero")
        String nomeGenero
    );

    @Query(nativeQuery = true, value =
        "SELECT f.titulo AS titulo, " +
        "       f.ano_lancamento AS ano, " +
        "       g.nome_genero AS genero, " +
        "       d.nome_diretor AS diretor, " +
        "       ROUND(AVG(a.nota), 1) AS media " +
        "FROM Filme f " +
        "JOIN Genero g ON g.id_genero = f.id_genero " +
        "JOIN Diretor d ON d.id_diretor = f.id_diretor " +
        "LEFT JOIN Avaliacao a ON a.id_filme = f.id_filme " +
        "WHERE f.id_filme = :idFilme " +
        "GROUP BY f.id_filme, f.titulo, f.ano_lancamento, g.nome_genero, d.nome_diretor")
    FilmeResumo buscarResumoPorId(
        @Param("idFilme")
        Integer idFilme
    );

}
